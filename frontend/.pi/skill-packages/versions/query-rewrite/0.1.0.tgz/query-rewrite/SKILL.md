---
name: query-rewrite
description: Rewrite natural-language quantitative research questions into the platform-owned structured query contract before planning or data retrieval. Use when a request mentions securities, markets, time ranges, comparisons, fundamentals, technical analysis, events, strategies, backtests, portfolios, or follow-up changes whose targets and intent must be normalized consistently.
---

# SignalForge Query Rewrite

Consume the platform-generated `.signalforge/query_rewrite.json` before interpreting a quantitative request. Treat it as the authoritative bridge between the user's wording, the run plan, and API-based data skills.

> `.signalforge/**` is platform-owned and read-only. Never create, edit, delete, or repair the rewrite artifact from the Agent runtime.

## Workflow

1. Read the rewrite contract supplied in the Task Packet or `.signalforge/query_rewrite.json`.
2. Use `resolvedSymbols[]` as the standard target list. Preserve its order and carry `symbol`, `market`, `assetType`, and `secid` into subsequent data requests.
3. Use `timeRange`, `analysisFocus`, `capabilityHint`, and `outputIntent` to verify the run plan. The run plan remains authoritative if a user-selected capability intentionally overrides the hint.
4. Respect the status gate:
   - `ready`: continue to `run-planner` and the required API-based data skills.
   - `partial`: continue only for resolved targets when the omitted targets do not change the requested comparison or portfolio semantics; otherwise ask one concise clarification.
   - `needs_clarification`: ask the questions implied by `issues[]` and stop before data retrieval.
5. Keep `originalQuery` for user-visible wording and use `rewrittenQuery` only as an execution summary. Never present rewritten text as a verbatim user quote.
6. Report issue codes exactly. Distinguish `TARGET_NOT_FOUND`, `TARGET_AMBIGUOUS`, and `SYMBOL_RESOLVER_UNAVAILABLE`; do not collapse them into “data unavailable.”

## Validation

Validate a received artifact when fields are missing or the status conflicts with the symbol list:

```bash
python .claude/skills/query-rewrite/scripts/validate_query_rewrite.py \
  --input .signalforge/query_rewrite.json
```

The script prints deterministic JSON, performs no network calls, and never writes files. A non-zero exit means the platform contract must be regenerated before continuing.

Read [query-rewrite-contract.md](references/query-rewrite-contract.md) when handling ambiguity, partial resolution, schema validation, or API error mapping.

## API handoff

- The platform creates the contract through `POST /api/quant/query/rewrite`; Agent code consumes the artifact rather than calling this platform endpoint again.
- Resolve only platform-approved missing targets through `GET /api/v1/symbols/resolve`.
- Pass standard codes—not raw Chinese names—to quote, history, indicator, fundamental, event, and backtest APIs.
- Preserve API `source`, `as_of`, `fetched_at`, `fetch`, and `data_quality` in evidence.
- Do not retry `TARGET_NOT_FOUND` unchanged. Retry `SYMBOL_RESOLVER_UNAVAILABLE` only when the platform marks it retryable.

## Completion boundary

Complete this skill when the target set, time range, analysis focus, capability hint, output intent, and clarification state are internally consistent. Data retrieval and dashboard generation belong to subsequent skills.
